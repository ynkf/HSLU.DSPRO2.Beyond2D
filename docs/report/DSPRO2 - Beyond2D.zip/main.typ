#set document(
  title: "DSPRO2 Scientific Report: Beyond2D",
  date: auto,
  author: ("")
)

#set table(
  inset: 6pt,
  stroke: none
)

#set heading(numbering: "1.")

#let is-first-page() = counter(page).get().first() == 1

#set page(
  numbering: "1/1",
  paper: "a4",
  footer: context [
    #h(1fr)
    #set text(size: 10pt)
    #counter(page).display(
      "1/1",
      both: true
    )
  ],
  header: context { 
    if(is-first-page()) [
      #figure(
        stack(
          dir: ltr,
          spacing: 7cm,
          image("graphics/HSLU_Logo_DE_Schwarz_rgb.png", width: 30%),
        ), numbering: none,
      )
    ] else [
      #set text(size: 10pt)
      DSPRO2 Scientific Report #h(1fr) Beyond2D
    ]
  }
)

#show bibliography: set heading(numbering: "1.")

#include "sections/titlepage.typ"
#pagebreak()

#outline(
  indent: auto,
  depth: 2
)

#pagebreak()

= Introduction
#include "sections/introduction.typ"
#pagebreak()

= Literature review
#include "sections/literature_review.typ"
#pagebreak()

= Data
#include "sections/data.typ"
#pagebreak()

= Methods
#include "sections/methods.typ"
#pagebreak()

= Results
#include "sections/results.typ"
#pagebreak()

= Model Integration
#include "sections/model_integration.typ"
#pagebreak()

= Machine Learning Operations
#include "sections/mlops.typ"
#pagebreak()

= Conclusions
#include "sections/conclusion.typ"
#pagebreak()

= Glossary
#include "sections/glossary.typ"
#pagebreak()

#text(size: 10pt, 
  bibliography("literature/sources.bib", style: "ieee", full: true, title: "References")
)