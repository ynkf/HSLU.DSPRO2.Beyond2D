== SfM/MVS Pipeline
The SfM/MVS pipeline consists of two primary stages: Structure from Motion for camera pose estimation and sparse reconstruction, followed by Multi-View Stereo for dense geometry recovery. This sequential approach transforms multiple overlapping images into detailed 3D models through systematic geometric analysis and optimization. The information on the pipeline is mainly from the HSLU's module "Computer Vision and Artificial Intelligence". @cvai

#figure(image("../graphics/SfM_MVS_pipeline.png", width: 70%),
  caption: [SfM/MVS pipeline]
)

=== Structure from Motion (SfM)
==== Input Requirements
SfM requires multiple photographs captured from different viewpoints with sufficient overlap to establish feature correspondences. Optimal results demand 60-80% overlap between adjacent images, ensuring robust feature matching across the image sequence. Camera motion should be smooth and deliberate, avoiding sudden movements that compromise tracking accuracy.

#pagebreak()

==== Feature Detection and Matching
The pipeline begins with identifying distinctive visual features across all input images. Modern implementations employ scale-invariant feature transform (SIFT), speeded-up robust features (SURF) or oriented FAST and rotated BRIEF (ORB) descriptors to ensure robust matching under varying illumination and perspective conditions.

#figure(image("../graphics/feature_detection.jpg", width: 60%),
  caption: [Feature detection]
)

Feature matching establishes correspondences between images by comparing descriptor similarity and enforcing geometric constraints. Robust estimation techniques, including Random Sample Consensus (RANSAC), eliminate outlier matches and ensure correspondence reliability. The resulting feature tracks connect the same physical points across multiple images, forming the foundation for geometric reconstruction.

#figure(image("../graphics/feature_matching.jpg", width: 60%),
  caption: [Feature matching]
)

==== Camera Pose Estimation
Camera pose estimation determines the 3D position and orientation of each camera relative to the scene coordinate system. This process employs fundamental matrix and essential matrix estimation for image pairs, followed by pose recovery through singular value decomposition.
Initial pose estimation often begins with a robust image pair selection, choosing images with strong feature correspondences and favorable geometric configuration. Subsequent images are incrementally added to the reconstruction through perspective-n-point (PnP) algorithms, progressively expanding the camera network.

==== 3D Point Triangulation
Triangulation converts 2D feature correspondences into 3D world coordinates using known camera poses. For each feature track, rays are projected from corresponding image points through their respective camera centers. The intersection of these rays determines the 3D point location, with geometric uncertainty handled through least-squares optimization.

#figure(image("../graphics/camera_pose_estimation.jpg", width: 50%),
  caption: [Camera pose estimation and 3D point triangulation]
)

==== Bundle Adjustment
Bundle adjustment represents the cornerstone optimization stage, simultaneously refining camera poses and 3D point positions to minimize reprojection errors across all observations. This non-linear optimization problem employs Levenberg-Marquardt algorithms to achieve convergence while maintaining numerical stability. The optimization objective minimizes the sum of squared reprojection errors: "*min Σᵢⱼ ||xᵢⱼ - π(Pᵢ, Xⱼ)||²*", where xᵢⱼ represents observed image coordinates, π denotes the camera projection function, Pᵢ represents camera parameters, and Xⱼ denotes 3D point coordinates.

#figure(image("../graphics/bundle_adjustment.png", width: 50%),
  caption: [Bundle Adjustment]
)

==== Sparse Point Cloud Generation
The SfM stage produces a sparse point cloud containing only reliably reconstructed feature points. This initial reconstruction captures the scene's geometric structure and camera configuration, providing the foundation for subsequent dense reconstruction. Quality assessment involves analyzing reprojection errors, track lengths, and geometric consistency across reconstruction.

=== Multi-View Stereo (MVS)
==== Depth Estimation
Modern MVS pipelines incorporate monocular depth estimation (MDE) to enhance reconstruction quality and completeness. Deep learning models, including MiDaS (hybrid CNN-Transformer) and DepthAnything (Vision Transformer), provide pixel-wise depth predictions for individual images.

Integration of MDE results with geometric reconstruction improves surface coverage and reduces reconstruction artifacts in textureless regions.

#figure(image("../graphics/monocular_depth_estimation.jpg", width: 50%),
  caption: [Monocular Depth Estimation]
)

==== Dense Matching
Dense matching extends correspondence establishment from sparse features to pixel-level accuracy. This process employs photometric consistency measures, including normalized cross-correlation (NCC) and zero-mean normalized cross-correlation (ZNCC), to identify corresponding pixels across multiple views.
Patch-based matching algorithms analyze local image neighborhoods to establish robust correspondences while handling photometric variations and geometric distortions. Advanced approaches employ cost-volume construction and optimization to achieve sub-pixel matching accuracy.

==== Depth Map Generation
Individual depth maps are generated for each input image through multi-view stereo matching. The process involves:

- *Reference Image Selection:* Each image acts as a reference, with neighboring images as sources

- *Cost Volume Construction:* Photometric costs are computed across depth hypotheses

- *Cost Aggregation:* Spatial consistency is enforced through filtering operations

- *Depth Optimization:* Winner-takes-all or global optimization selects optimal depth values

==== Depth Map Fusion
Multiple depth maps must be fused into a consistent 3D representation to handle overlapping coverage and resolve conflicts between different viewpoints. Fusion algorithms consider depth uncertainty, viewing angle effects, and photometric confidence to weight contributions from different maps.
Truncated Signed Distance Function (TSDF) fusion represents a popular approach, maintaining a volumetric grid where each voxel stores distance-to-surface measurements. This representation naturally handles multiple observations and produces smooth, consistent surfaces.

==== Dense Point Cloud Generation
Dense matching results are converted to 3D coordinates through triangulation, producing point clouds with significantly higher density than the initial sparse reconstruction. Quality filtering removes points with high geometric uncertainty or poor photometric consistency.

The resulting dense point cloud contains millions of 3D points representing detailed surface geometry, capturing fine-scale features and object boundaries with high fidelity.

==== Mesh Reconstruction
Surface reconstruction transforms dense point clouds into continuous polygon meshes suitable for rendering and visualization. Poisson reconstruction represents the most widely adopted approach, solving for a smooth surface that best fits the oriented point data.
The Poisson formulation treats surface reconstruction as solving: "*∇ · ∇χ = ∇ · V*", where χ represents the indicator function and V denotes the vector field derived from oriented points.

== Monocular Depth Estimation

Monocular depth estimation is the process of inferring a dense depth map where each pixel in an image has a depth value. It uses only one RGB image and does not rely on stereo or multi-view input. Because a single image lacks explicit 3D information, the task depends on visual cues and prior knowledge about the structure of the world.

=== Absolute and Relative Depth

Depth information can be represented in two primary forms: absolute (or metric) and relative. The distinction between these is crucial for understanding the capabilities and limitations of different depth estimation models and datasets. @monocular_depth_estimation

==== Absolute (Metric) Depth
Absolute depth refers to the physical distance between the camera sensor and an object or point in the scene, measured in real-world units like meters or centimeters. It is typically captured by active sensors that can directly measure depth, such as LiDAR scanners, Time-of-Flight (ToF) cameras, Structured light sensors (like the Microsoft Kinect), and stereo camera setups with a known distance between cameras.

Datasets providing absolute depth, such as DepthAnything V2, serve as essential ground truth for training and evaluating depth estimation models. A model that predicts absolute depth can be directly used for tasks requiring real-world scale, such as robotics, augmented reality, and accurate 3D measurement.

==== Relative Depth
Relative depth, in contrast, does not have a true, meaningful scale. It preserves the depth ordering and structure of the scene, meaning it can correctly determine that one object is closer than another, but the output values are not tied to any physical unit. For example, a relative depth map might indicate that one pixel has a depth value of 0.5 and another has a value of 0.2, but this only implies a relative distance, not a specific measurement in meters.

#pagebreak()

=== Loss Functions
Training a depth estimation model on diverse datasets or for the general task of relative depth prediction, presents a significant challenge: the ground truth depth maps often lack a consistent scale and shift. A standard regression loss like L2 or L1 would be skewed by these variations. To overcome this, we employ a loss function invariant to these affine transformations, compelling the model to learn the underlying geometric structure of the scene rather than dataset-specific scaling conventions.

The core of this objective is an affine-invariant Mean Absolute Error (MAE) loss computed in disparity space. First, depth values $t$ are converted to disparity $d$ via the relation $d = 1/t$. Then, instead of directly comparing the predicted disparity map $bold(d)^*$ and the ground truth disparity map $bold(d)$, each map is independently normalized to have a zero median (shift-invariance) and a unit mean absolute deviation (scale-invariance).

The loss $L$ is defined as the MAE between these aligned maps:

#text(size: 8.5pt,$ L = 1/(H W) sum_(i=1)^(H W) | hat(d)_i^* - hat(d)_i | $)

where $hat(d)_i^*$ and $hat(d)_i$ are the aligned prediction and ground truth values for pixel $i$. The alignment for any given disparity map $bold(d)$ is performed as follows:

#text(size: 8.5pt, $ hat(d)_i = (d_i - t(bold(d))) / s(bold(d)) $)

The term $t(bold(d))$ provides shift-invariance by centering the distribution at zero using the median, which is robust to outliers:

#text(size: 8.5pt,$ t(bold(d)) = "median"(bold(d)) $)

The term $s(bold(d))$ provides scale-invariance by normalizing the map's spread using the mean absolute deviation:

#text(size: 8.5pt,$ s(bold(d)) = 1/(H W) sum_(i=1)^(H W) |d_i - t(bold(d))| $)

By computing the loss on these normalized maps, the model is penalized only for differences in structure, not for the scale and shift, which can be arbitrary across different scenes and datasets. This base loss can be further augmented with other terms, such as a gradient-matching component, to better enforce the preservation of sharp details and high-frequency textures. @ranftl2020towards

=== Models
To start with the best possible model as a base to build up on, we had to evaluate them on the DeepFurniture Dataset. For this, we use the two state-of-the-art models, MiDaS and Depth Anything V2, in the biggest publicly available version.

==== MiDaS
MiDaS is a Monocular Depth Estimation model built by Intel. A key characteristic of MiDaS is its training methodology, which involves leveraging multiple diverse datasets (up to 10 in some versions, including a mix of LiDAR, stereo and 3D film data). To handle the inherent differences in scale and shift across these varied datasets, MiDaS employs a scale and shift-invariant loss function during training. This approach enables the models to generalize well to unseen environments and produce high-quality relative depth maps from single RGB images. Several versions of MiDaS exist, offering different trade-offs between accuracy and computational cost, often utilizing transformer-based (e.g., DPT) or convolutional backbones.

==== Depth Anything V2
Depth Anything V2 @depth_anything_v2 is a more recent and powerful model for monocular depth estimation, building upon its predecessor, Depth Anything @depth_anything_v1. A core strategy in Depth Anything V2 involves a sophisticated training pipeline emphasizing data quality and scale. Notably, it replaces labeled real images from its V1 training with high-quality synthetic images for initial teacher model training. This teacher model, often with a scaled-up capacity (e.g., using DINOv2-G encoders), is then used to generate pseudo-labels for a vast corpus of unlabeled real-world images (around 62 million). The final student models, available in various sizes (e.g., Small, Base, Large) to cater to different application needs, are trained on these pseudo-labeled real images. This multi-stage approach, combining precise synthetic data with large-scale, diverse real-world imagery via a teacher-student paradigm, allows Depth Anything V2 to produce exceptionally robust depth predictions with fine-grained details across a wide array of scenes. It aims to provide a versatile solution for relative depth estimation, and can also be fine-tuned for metric depth.

==== Comparison
#[
  #set align(center)
  #figure(
    table(
      align: (x, _) => if x == 0 { left } else { center },
      columns: (auto, auto, 60pt, 50pt, 50pt),
      table.header[Model][AbsRel ↓][δ₁ ↑][δ₂ ↑][δ₃ ↑],
      table.hline(y: 1, stroke: 1pt),
      [Midas],  [*0.1464*], [0.8446], [0.9601], [0.9816],
      [DepthAnythingV2], [0.1755], [*0.8862*], [*0.9719*], [*0.9864*],
    ),
    caption: [Performance measures of pretrained and finetuned DepthAnythingV2 (Beyond2D) models on DeepFurniture dataset. The metrics include AbsRel ↓ (lower is better), and the threshold accuracies δ₁, δ₂, and δ₃ ↑ (higher is better).]
  )
]

The results present a nuanced comparison between the two models on relative depth. The predictions were scaled to the ground truth to make both models comparable. 

Notably, MiDaS achieved a lower (better) Absolute Relative Error, suggesting its average per-pixel error is smaller across the dataset. However, Depth Anything V2 demonstrated superior performance across all other key metrics.

Depth Anything V2 achieved a significantly lower RMSE, indicating that it produces fewer large errors than MiDaS. This is a critical advantage, as large errors can have a more detrimental impact on 3D reconstruction tasks. Furthermore, its superiority is confirmed by the delta accuracy metrics ($delta_1, delta_2, delta_3$), where it consistently outperformed MiDaS. The most significant gap is observed in the $delta_1$ accuracy, with Depth Anything V2 correctly predicting the depth of 88.6% of pixels within the strictest threshold, compared to 84.5% for MiDaS.

In conclusion, while MiDaS shows a strong performance in relative error, Depth Anything V2 proves to be the more robust and reliable base model for the DeepFurniture dataset. Its ability to avoid major prediction errors (lower RMSE) and its higher overall pixel accuracy (higher $delta$ values) make it a stronger foundation model for our fine-tuning task. This suggests that Depth Anything V2's internal representations are better suited for complex indoor scenes and furniture geometries present in this dataset.

