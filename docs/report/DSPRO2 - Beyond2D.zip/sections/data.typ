== Datasets
=== DeepFurniture
For fine-tuning our depth estimation model, we used the DeepFurniture dataset @liu2019furnishing by \ COOHOM/酷家乐. DeepFurniture is a large-scale dataset designed for furniture understanding, containing a rich collection of photo-realistic rendered indoor scenes, which is crucial for training models for indoor environments.

The DeepFurniture dataset consists of approximately 24'000 photo-realistic indoor images. These scenes were all rendered using COOHOM's render engine and contain 170'000 annotated furniture instances derived from 20'000 unique 3D furniture models. Furthermore, the furniture is categorized into 11 types and 11 distinct styles.

#figure(image("../graphics/deepfurniture_overview.png"),
  caption: [Overview of contents in DeepFurniture dataset]
)

The key strength of DeepFurniture is its multiple annotation levels:
- *Image Level:* Provides the rendered indoor scenes along with their categories and, crucially for our work, depth maps.
- *Instance Level:* Includes bounding boxes and segmentation masks for individual furniture items within the scenes.
- *Identity Level:* Offers high-quality rendered previews of the 3D furniture models.

=== Living Room Dataset
We use the living room dataset @living_room_dataset to test and evaluate our SfM/MVS pipeline. The dataset provides a synthetic indoor scene rendered in high fidelity, with images generated from tightly spaced camera viewpoints. This is a key requirement for successful SfM, which relies on strong feature overlap and consistent viewpoint transitions. We chose this dataset primarily for its convenience: it allows us to bypass the time-consuming process of capturing real-world image sequences while still providing a realistic testbed with fine-grained control.

#figure(image("../graphics/Living-Room-dataset.png"),
  caption: [Overview of contents in the Living Room dataset]
)

=== Unused Datasets
==== NYU Depth V2
Another dataset we initially wanted to use is NYU Depth V2 @Silberman:ECCV12, but we later decided against it due to it already being used in training DepthAnythingV2.
This dataset consists of video sequences captured by Microsoft's Kinect camera in various indoor scenes.


It features 1,449 densely labeled pairs of aligned RGB and depth images. These images span 464 distinct indoor scenes taken from three different cities. An important characteristic of the labeled depth data is that it has been preprocessed to fill in missing depth values using the colorization scheme by Levin et al., providing complete depth maps. While the dataset also contains a much larger set of unlabeled frames (407,024) and raw Kinect data, our focus would have been on these aligned RGB-D pairs. The labeled data is provided as a Matlab `.mat` file and includes per-pixel class and instance labels in addition to the depth information.

#figure(image("../graphics/nyu_depth_v2_overview.jpg"),
  caption: [Overview of contents in NYU Depth V2 dataset]
)

For each labeled pair, there is the original RGB image (left), the depth map (middle), and a labeled image (right).

== Data Analysis
To better understand the characteristics of the DeepFurniture dataset, we computed the following statistical metrics for each depth map:

- *`min_depth`*: Minimum depth value in the image
- *`max_depth`*: Maximum depth value in the image
- *`mean_depth`*: Average depth value
- *`std_depth`*: Standard deviation of depth values
- *`median_depth`*: Median depth value
- *`depth_range`*: Difference between the maximum and minimum depth values

These metrics were chosen to give a clear and useful summary of each depth map. Since the dataset contains around 24,000 images, it’s not possible to load all of them into memory at once for analysis. To solve this, we calculated summary statistics for each image individually. This allowed us to create a smaller, more memory-efficient dataset that we could use for analysis and visualization.

#pagebreak()

=== Histogram

Histograms were generated for all six metrics to explore their distributions across the dataset:

#figure(image("../graphics/data/depth-histogram.png", height: 250pt),
  caption: [Histogram showing depth distribution across the dataset]
)

*`mean_depth`*: The distribution is moderately skewed, with most depth maps centered around typical average depth values, suggesting consistency in scene scale.

*`std_depth`*: A right skew shows differences in depth complexity. Some scenes have little variation (like flat or uniform surfaces), while others have a lot, suggesting more detailed spatial structure.

*`depth_range`*: Displays a long-tailed distribution, with most depth maps having moderate range and a few exhibiting extremely large depth spreads, likely due to scenes combining close and distant elements.

*`min_depth`*: Peaks near zero, implying that many images contain very close foreground elements or sensor artifacts.

*`max_depth`*: While many depth maps reach similar maximum values, the long right tail reveals the presence of far background elements in certain scenes.

*`median_depth`*: Follows a similar shape to the mean depth distribution but with slightly less spread, reflecting typical scene depth while minimizing the impact of extreme values.

#pagebreak()

=== Boxplot

Box plots were created for all metrics to provide a concise summary of their variability and to detect outliers:

#figure(image("../graphics/data/depth-boxplot.png", height: 220pt),
  caption: [Boxplots showing depth variability and outliers across the dataset]
)

*`min_depth`*: Shows low values for most images, with some outliers indicating closer-than-typical foreground objects.

*`max_depth`*: Exhibits the largest number of extreme outliers, consistent with the presence of very distant elements in select scenes.

*`mean_depth`* and *`median_depth`*: Indicate a relatively consistent central tendency across images, though both show significant outliers.

*`std_depth`*: Highlights wide variability in depth structure, with a heavy concentration of outliers for scenes with high spatial complexity.

*`depth_range`*: Displays substantial spread and the most extreme outliers of all metrics, underlining the diversity of depth compositions in the dataset.


#pagebreak()

=== Maximum Depth Metric

To better understand the extreme values in the *`max_depth`* distribution, we examined several of the most significant outliers. 

#figure(image("../graphics/data/max-depth-outliers.png", height: 200pt),
  caption: [Examples with high maximum depth values]
)

In each case, the RGB images (top row) and their corresponding depth maps (bottom row) reveal that:

- The extremely high depth values are often caused by windows or transparent surfaces, where the depth estimation extends unnaturally far into the background.

- In some instances, only a few isolated pixels contain unusually large values that are inconsistent with the surrounding scene. These are likely due to rendering artifacts or sensor noise.



== Data Cleaning

The data analysis revealed a recurring issue in the dataset: certain depth maps contain extremely high depth values, often well beyond the expected range for indoor scenes. These anomalies are most commonly found near windows or transparent surfaces, where the depth renderer appears to return values corresponding to far-away backgrounds. In some cases, only a few isolated pixels exhibit these abnormal values, likely due to rendering artifacts or sensor inconsistencies.

These extreme values are problematic, especially when training models like Depth Anything assume a maximum depth of 20 meters by default. In our dataset, this corresponds to a numeric threshold of 20,000 units. Values exceeding this limit may cause the model to misinterpret the scene geometry, skew learning, or reduce generalization.

To address this, we propose two main strategies:

1. Threshold-Based Filtering (Simple and Effective)
2. In-Image Depth Cleaning (Advanced, Targeted)

#pagebreak()

=== Threshold-Based Filtering
The simplest approach is to exclude any depth maps with a maximum depth greater than 20,000 (20 meters) from the dataset. This prevents outliers from influencing the training process and aligns the dataset with the expected input range of most depth estimation models.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/data/depth-boxplot-cleaned.png"),
  ),
  caption: [Box plots after data cleaning with threshold filtering.]
)

After applying threshold filtering, the dataset contains significantly fewer outliers than before. We decided to retain the remaining outliers and will perform additional data cleaning if the model demonstrates poor performance.

=== In-Image Depth Cleaning
Upon initial inspection of the DeepFurniture dataset, we identified a significant data quality issue in scenes containing windows. The depth maps in these regions often exhibited extreme depth values, which is common for transparent or highly reflective surfaces where depth sensors like to fail. These anomalous values severely degraded the performance of our fine-tuned depth estimation model during training.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/dc_image.jpg"),
    image("../graphics/dc_depth.png")
  ),
  caption: [Left: original image; Right: original depth map]
)

To address this issue, we developed a preprocessing pipeline to identify window regions and correct their depth values. Our approach assumes that the depth of a window should be consistent with the depth of the surrounding wall. We explored two distinct methods for this correction task.

==== Method 1: Semantic Segmentation
Our first approach was to explicitly detect windows using a pre-trained semantic segmentation model @csurka2023semanticimagesegmentationdecades. We utilized the nvidia/segformer-b5-finetuned-ade-640-640 model @xie2021segformer, a powerful vision transformer fine-tuned on the ADE20K dataset @zhou2017scene. The process was as follows:

1. *Inference:* For each scene's RGB image, the Segformer model was used to generate a semantic segmentation map.
2. *Mask Generation:* We created a binary mask by isolating the pixels classified as "window" or "windowpane" (class IDs 8 and 21 in the ADE20K label set).
3. *Boundary Analysis:* The generated window mask was then eroded by a few pixels. The boundary region (the original mask minus the eroded mask) was assumed to represent the wall area immediately surrounding the window.
4. *Depth Correction:* The median depth value of the pixels in this boundary region was calculated. This median wall depth was then used to fill the entire window area in the original depth map, creating a corrected version.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/dc_mask.png"),
    image("../graphics/dc_depth_corrected_wd.png")
  ),
  caption: [Left: generated mask; Right: mask applied to depth map]
)

While theoretically sound, this method proved to be suboptimal. The pre-trained segmentation model struggled to reliably and accurately identify windows across the diverse scenes of the DeepFurniture dataset, often resulting in incomplete or incorrect masks. This unreliability led us to explore a more direct and robust alternative.

==== Method 2: Direct Depth-Based Thresholding
Given the shortcomings of the segmentation-based method, we implemented a simpler yet more effective approach that operates directly on the depth maps. This method is based on the observation that anomalous window depths are almost always the largest values in a given scene's depth map.

1. *Thresholding:* For each depth map, we calculated a high-percentile depth value from all valid (non-zero) pixels. Any pixel with a depth greater than this threshold was considered part of a potential window region.
2. *Mask Cleaning:* This initial depth mask was often noisy. To get a cleaner shape, we applied morphological operations. First, a "binary closing" filling small holes and then a "binary opening" removing any small, isolated noise patches.
3. *Depth Correction:* With this cleaned window mask, we applied the same boundary analysis and median-fill technique as in the first method. The boundary pixels of the mask were used to determine the surrounding wall's depth, which then filled the entire window region in the depth map.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/dc_depth.png"),
    image("../graphics/dc_depth_corrected.png")
  ),
  caption: [Left: original depth map; Right: corrected depth map]
)

This direct depth correction method proved significantly more reliable and robust for our fine-tuned model.
By sidestepping the challenges of semantic understanding and instead leveraging the distinct numerical properties of the depth data itself, we consistently corrected the anomalous window depth values, thereby improving the overall quality of the dataset for fine-tuning the model. All subsequent experiments were conducted using the preprocessed depth maps using this second method.


== Preprocessing
Preprocessing was performed prior to training to reduce computational overhead during model execution and to enable full utilization of GPU resources. In particular, each sample's RGB image was resized and normalized, while the corresponding depth map was also resized, scaled from millimeters to meters, and thresholded to exclude outlier values above 20 meters.

The processed image-depth pairs were stored in an HDF5 format, which offers a balance between disk I/O performance and memory efficiency. This format allows the data to be lazily loaded during training, preventing memory overflow while maintaining fast access speeds. Each subset (train, validation, test) was saved as a separate HDF5 file, with individual samples organized into compressed datasets to further optimize storage and retrieval performance.

== Data Splitting

After data cleaning and preprocessing, the dataset was randomly split into training, validation, and test subsets with a ratio of 80% / 10% / 10%. This stratified split was applied at the sample level, maintaining a balanced distribution across all data partitions.

