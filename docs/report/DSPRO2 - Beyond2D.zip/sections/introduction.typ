== Project idea
Our project covers the 3D reconstruction of apartments using image data. Specifically, we aim to integrate a self-trained monocular depth estimation model into an existing Multi-View Stereo (MVS) pipeline. This approach will allow us to enhance the accuracy and robustness of 3D models generated from limited image inputs.

== Problem definition
When browsing apartment listings online, users are typically limited to 2D images that lack depth information. These flat images can be misleading, especially when wide-angle lenses distort the space. Without a clear sense of scale or layout, it's difficult for potential renters or buyers to understand the true dimensions of the space. Our project addresses this issue by reconstructing the apartment in 3D, providing a more accurate and immersive view.

== Motivation
The real estate market increasingly relies on digital platforms, yet the viewing experience remains largely two-dimensional. Virtual tours and 3D visualizations are becoming more in demand as people seek more convenient, informative and remote ways to evaluate properties. Our motivation is to improve the digital viewing experience and make property assessments more accurate and user-friendly.

== Objectives
For our project we have the following objectives:

- Train a monocular depth estimation model specifically tailored for indoor scenes.

- Integrate this model into an existing MVS reconstruction pipeline to improve depth information from sparse or uncalibrated image sets.

- Evaluate the impact of our depth estimator on reconstruction quality compared to baselines.

- Produce 3D models from the dense point cloud from the SfM/MVS pipeline.

== Relevance 
This project is relevant to fields such as real estate, virtual reality and computer vision. In particular, our contribution to enhance an existing MVS pipeline with a learned monocular depth estimation, addresses a real-world need: generating spatially accurate 3D environments from collected imagery from apartments. This makes the technology accessible and useful for real estate listings, interior design planning and virtual property viewings.