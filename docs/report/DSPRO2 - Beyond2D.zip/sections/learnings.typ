Write intro for learnings

== Technical Insights
--

== Project Management Strategies
--

== Reflections on the Project Process
--

== Conclusion
--