== Version Control
The entire project was managed under a version control system to ensure full traceability. All code for data preprocessing, model training, and evaluation was versioned using Git and stored in a public GitHub repository.

The repository can be accessed at #link("https://github.com/ynkf/HSLU.DSPRO2.Beyond2D").

== Cloud Computing
Our experiments, particularly the fine-tuning of large depth estimation models, required significant computational resources. We utilized the computing infrastructure provided by the HSLU, which was accessed via the centrally managed GPUHub, also known as JupyterHub platform. This environment provided on-demand access to powerful hardware for rapid iteration and model training.

== Experiment Tracking
We use Weights & Biases (W&B) for experiment tracking. For each training and validation run, we logged the following information to the W&B platform:

- *Hyperparameters:* learning_rate, weight_decay, warmup_epochs, scheduler_rate, mixed_precision
- *Performance Metrics:* loss, absolute relative error, delta1
- *Model Artifact:* The trained model weights were saved as W&B artifacts, directly linked to its corresponding experiment.

#figure(
  grid(
    columns: 2,
    rows: 3,
    gutter: 2mm,
    image("../graphics/mlops/train-loss.png"),
    image("../graphics/mlops/val-loss.png"),
    image("../graphics/mlops/train-absRel.png"),
    image("../graphics/mlops/val-absRel.png"),
    image("../graphics/mlops/train-delta1.png"),
    image("../graphics/mlops/val-delta1.png"),
  ),
  caption: [Metrics from top to bottom: loss, AbsRel, δ₁]
)