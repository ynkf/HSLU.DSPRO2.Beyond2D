#linebreak()
#linebreak()
#linebreak()

#align(center, text(30pt)[
  *Scientific Report for DSPRO2 Course (FS25)*
])

#align(center, text(22pt)[
  *Beyond2D*
])

#align(center, text(16pt)[
  *Generate 3D models from 2D images*
])

#linebreak()

#align(center, text[
  Fabian Dubach <#link("fabian.dubach@stud.hslu.ch")> #linebreak()
  Timon Schmid <#link("timon.schmid@stud.hslu.ch")> #linebreak()
  Yannick Frischknecht <#link("yannick.frischknecht@stud.hslu.ch")> #linebreak()
])

#linebreak()

#align(center, text[
  Rotkreuz, June 2025
])

#linebreak()

#figure(image("../graphics/beyond2d.jpg", height: 300pt),
  caption: [Visualization showcasing the reconstruction of a complete and detailed 3D interior from multiple 2D source images.]
)
