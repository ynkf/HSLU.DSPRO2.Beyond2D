In this project, we introduce Beyond2D, a depth refinement framework designed to enhance monocular absolute depth estimation from pretrained models. As 3D reconstruction requires accurate depth estimation we built on the capabilities of Metric DepthAnythingV2 (absolute depth) and demonstrate consistent improvements in both quantitative metrics and qualitative outputs. Our method is evaluated on the DeepFurniture dataset, where Beyond2D-fine-tuned models outperform their pretrained counterparts in key performance metrics, including AbsRel and threshold accuracies δ₁, δ₂, and δ₃. Additionally, we present visualizations that highlight the refinement in depth pretictions, confirming the effectiveness of Beyond2D in producing more accurate and structured depth maps.

== Performance

#[
  #set align(center)
  #figure(
    table(
      align: (x, _) => if x == 0 { left } else { center },
      columns: (auto, auto, 60pt, 50pt, 50pt, 50pt),
      table.header[Model][Encoder][AbsRel ↓][δ₁ ↑][δ₂ ↑][δ₃ ↑],
      table.hline(y: 1, stroke: 1pt),
      [Metric DepthAnythingV2], [ViT-S], [0.9090], [0.1524], [0.5477], [0.8142],
      [Beyond2D - Metric DepthAnythingV2], [ViT-S], [0.2230], [0.8375], [0.9561], [0.9811],
      table.hline(y: 3, stroke: 0.5pt),
      [Metric DepthAnythingV2], [ViT-L], [0.8728], [0.1738], [0.5994], [0.8407],
      [Beyond2D - Metric DepthAnythingV2], [ViT-L], [*0.1309*], [*0.9080*], [*0.9687*], [*0.9848*],
      table.hline(y: 5, stroke: 0.5pt),
    ),
    caption: [Performance measures of pretrained and finetuned DepthAnythingV2 (Beyond2D) models on DeepFurniture dataset. The metrics include AbsRel ↓ (lower is better), and the threshold accuracies δ₁, δ₂, and δ₃ ↑ (higher is better).]
  )
]

For the ViT-S backbone, the pretrained Metric DepthAnythingV2 model achieves an AbsRel of 0.9090, with δ₁, δ₂ and δ₃ scores of 0.1524, 0.5477 and 0.8142. After fine-tuning with Beyond2D, the model achieves improved performance with an AbsRel of 0.2230 and δ₁, δ₂ and δ₃ values of 0.8375, 0.9561, and 0.9811.

For the ViT-L backbone, the pretrained Metric DepthAnythingV2 model achieves an AbsRel of 0.8728, with δ₁, δ₂ and δ₃ values of 0.1738, 0.5994 and 0.8407. The Beyond2D-finetuned variant shows further improvement, reaching an AbsRel of 0.1309 and threshold accuracies of 0.9080, 0.9687 and 0.9848, respectively.

#pagebreak()

== Visualizations
In the following visualizations, we compare the ground truth depth with the pretrained and finetuned prediction output.

#figure(image("../graphics/results/absolute-depth-visualization-small.png"),
  caption: [DepthAnythingV2-Small depth map comparison]
)

The figure above compares depth predictions from pretrained and fine-tuned DepthAnythingV2 models using the ViT-S backbone on a sample from the DeepFurniture dataset. The leftmost panel shows the input RGB image, followed by the ground truth depth map from the dataset. The third panel presents the output of the pretrained DepthAnythingV2 (ViT-S), which captures structural details well but tends to overestimate depth, producing values beyond the actual scene range. The final panel displays the output from the Beyond2D-fine-tuned model. While this prediction lies closer to the correct depth range, it suffers from a noticeable loss of spatial detail and appears overly smooth and blurred.

#figure(image("../graphics/results/absolute-depth-visualization-large.png"),
  caption: [DepthAnythingV2-Large depth map comparison]
)

In this example, using the ViT-L encoder, the pretrained model again overestimates depth values but retains well-defined object boundaries. The fine-tuned model produces depth predictions that closely match the ground truth in range, while also recovering more scene details compared to the ViT-S variant. However, some fine structures remain imperfectly resolved.