To see how well our fine-tuned DepthAnythingV2 model performed in practice, we decided to integrate it into an existing 3D reconstruction pipeline. We chose COLMAP as our testing ground because of its modular design, which gave us the flexibility to swap out specific components. This meant we could replace the traditional geometric depth estimation methods with our AI-powered approach while keeping everything else stable and reliable.

== How COLMAP Works
COLMAP is a comprehensive toolkit for turning a set of images into detailed 3D models. It works through several distinct steps, which can also be seen in the SfM/MVS chapter: first extracting features from images, then matching those features between different photos, creating a sparse 3D structure and finally building a dense, detailed reconstruction.

The process starts by finding and matching SIFT features across all the input images. Those can be imagined as distinctive visual landmarks that the system can recognize from different angles. Once these matches are established, COLMAP uses incremental SfM techniques to figure out where the camera was positioned for each photo and creates a basic 3D skeleton of the scene. The final step uses patch-match stereo algorithms to fill in all the details, generating comprehensive depth maps for every viewpoint.

What comes out of this process are two main products: a sparse point cloud with thousands of reliable 3D points that capture the basic structure of the scene, and a dense point cloud that can contain millions of points representing every surface detail possible.

While COLMAP is a powerful tool for 3D reconstruction, it can be prone to instability under certain conditions. The system can become quite unstable when handling large image sets, often struggling to maintain consistent feature matching across extensive collections. Image spacing is another challenge. Photos must be taken from positions close enough to ensure sufficient overlap for reliable feature detection. When viewpoints are too far apart, overlap decreases and leads to poor matching performance. There are also some issues when using the sequential matcher: a single poorly matched image can halt the entire reconstruction process. To bypass this problem, the exhaustive matcher can be used, which doesn't check for the perfect order of the images. In general, the  COLMAP pipeline could still be improved by fine-tuning every parameter perfectly for this task.

== Integration Approach
We integrated our DepthAnythingV2 model right at the dense reconstruction stage, essentially replacing COLMAP's patch-match stereo depth estimation with our neural network predictions. This strategy allowed us to get the best of both worlds: we could still rely on COLMAP's proven geometric methods for figuring out camera positions, while leveraging modern deep learning for the actual depth estimation.

We first let COLMAP run its standard patch-match stereo process to set up the dense reconstruction framework, then we carefully replace those geometric depth maps with our DepthAnythingV2 predictions. This two-step approach ensures that everything plays nicely with COLMAP's existing fusion and meshing algorithms, while giving us the enhanced depth estimation we were after. The key was making sure our neural depth maps used the same spatial resolution and coordinate system as the original estimates, so the integration would be seamless.

#pagebreak()

== Results Basic DepthAnythingV2
Our experiments with the pretrained DepthAnythingV2 model (before any custom training) already showed some improvements over the traditional COLMAP reconstruction. Our chosen monocular depth estimation model already detected more feature points, which the traditional COLMAP pipeline couldn't detect. The model slightly improved on blank walls, textureless surfaces and also on smaller details, which are hard to match without a good depth estimation.

In the scene below, which was taken in a real living room, some minor improvements can be observed. For example, the gap in the wall got a bit smaller and the whole wall seems more complete. On the right-hand side, the grey curtain also seems fuller. The metal stand structure, which can be seen in the front on the right side, appears more stable and complete, with less fragmentation in the point cloud reconstruction. The same goes for the two plants on and under the metal stand. Overall, the number of points was doubled (from 231'952 to 491'578), which indicates that this approach is already working and successfully generating denser reconstructions.


#figure(
  grid(
    columns: 3,
    gutter: 2mm,
    image("../graphics/snapshots_point_clouds/baskets_real.jpg", height: 70mm),
    image("../graphics/snapshots_point_clouds/baskets_traditional.png", height: 70mm),
    image("../graphics/snapshots_point_clouds/baskets_pretrained.png", height: 70mm)
  ),
  caption: [Left: Real picture of the scene; Middle: Traditional COLMAP approach; Right: COLMAP with pretrained DepthAnythingV2]
)

On the second scene that we tested, we could already see some bigger improvements. The whole scene seems much fuller with the integrated DepthAnythingV2 depth estimation. This can also be observed in the number of generated points: The traditional COLMAP pipeline generated 255'566 points, whereas our adjusted MVS generated 524'738 points - so again almost twice as much. This is especially visible in the left corner of the room and also on the table. The noise also got a bit worse, but this is due to the fact that the SfM approach has some problems with reflections in the scene.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/snapshots_point_clouds/couch_traditional.png", height: 50mm),
    image("../graphics/snapshots_point_clouds/couch_pretrained.png", height: 50mm)
  ),
  caption: [Left: Traditional COLMAP approach; Right: COLMAP with pretrained DepthAnythingV2 ]
)

#pagebreak()

== Results Trained DepthAnythingV2
Our fine-tuned DepthAnythingV2 model, which we trained specifically on the DeepFurniture dataset, showed minor improvements over the pretrained version. It performed a bit better on textureless surfaces and small details. The number of feature points also increased again, which indicates some improvements.

In the scene from the real living room, the gap in the wall decreased once more, which shows the above-mentioned performance boost on the textureless areas. Besides this, the two scenes appear nearly identical, which is also reflected in the feature point counts: The pipeline using the pretrained model produced 491'578 points, while the fine-tuned version generated only a marginally higher count of 491'608 points.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/snapshots_point_clouds/baskets_pretrained.png", height: 70mm),
    image("../graphics/snapshots_point_clouds/baskets_trained.png", height: 70mm)
  ),
  caption: [Left: Traditional COLMAP approach; Right: COLMAP with pretrained DepthAnythingV2]
)

For the second scene with the synthetic living room, the improvements are more noticeable. The left corner of the room looks denser and more complete. The balcony on the right side also became more dense with the fine-tuned model. The feature points increased from 524'738 to 609'938, which shows better scene coverage, though this also resulted in more noise being captured along with the additional detail.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/snapshots_point_clouds/couch_pretrained.png", height: 50mm),
    image("../graphics/snapshots_point_clouds/couch_trained.png", height: 50mm)
  ),
  caption: [Left: Traditional COLMAP approach; Right: COLMAP with pretrained DepthAnythingV2 ]
)

#pagebreak()

== Cleaning Up the Results
Even with all these improvements from the inserted depth estimation, the reconstructed point clouds still needed additional post-processing to reach production quality standards. We developed a Python-based filtering algorithm to tackle the most common issues: removing geometric outliers and reducing noise artifacts.

Our statistical outlier removal process eliminated points with extreme depth values that were clearly wrong, while radius-based filtering got rid of isolated points that didn't have enough neighboring points to be reliable.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/snapshots_point_clouds/couch_unfiltered.png"),
    image("../graphics/snapshots_point_clouds/couch_filtered.png")
  ),
  caption: [Left: Uncleaned scene; Right: Cleaned with Python-based algorithm]
)

These automated processing steps made a significant difference in visual quality, though we found that some manual point removal was still necessary to achieve perfectly clean models suitable for professional visualization work.

#figure(
  grid(
    columns: 2,
    gutter: 2mm,
    image("../graphics/snapshots_point_clouds/couch_filtered.png"),
    image("../graphics/snapshots_point_clouds/couch_manual_filtered.png")
  ),
  caption: [Left: Cleaned with Python-based algorithm; Right: Manual point removal]
)

#pagebreak()

== Creating the Final Meshes
The last step in our reconstruction pipeline involved converting those dense point clouds into polygon meshes using Poisson surface reconstruction. The resulting meshes did a great job of capturing the room geometry and furniture arrangements.

#figure(image("../graphics/snapshots_point_clouds/couch_mesh.png", width: 100%),
  caption: [Created mesh from cleaned-up dense point cloud]
)

However, even our enhanced process wasn't perfect. The meshes typically contained various geometric artifacts requiring substantial manual cleanup to achieve professional-quality results. Common issues included surface discontinuities at object boundaries, geometric noise in areas with low texture and incomplete surface coverage in spots where objects blocked the view.

While our enhanced depth estimation reduced these problems compared to traditional methods, getting to perfectly cleaned architectural models suitable for virtual tours still required significant post-processing work.

== Putting Together Complete Apartments
Reconstructing entire apartments from individual room captures could be effectively approached through a multi-scene integration strategy. In this workflow, each room or scene would be reconstructed separately, using a detailed depth estimation pipeline. Later, they would be combined within a 3D modeling environment to form a comprehensive apartment model.

This method offers a practical alternative to attempting a full-apartment reconstruction in a single pass, which can be limited by occlusions, large-scale alignment errors or processing constraints (e.g. too many images for COLMAP). The integration could rely on aligning rooms using architectural features such as shared walls, doorways or floor plans, followed by refinement steps to ensure geometric consistency at the seams. Such a pipeline would allow scalable, modular reconstruction while preserving high geometric fidelity at the room level.