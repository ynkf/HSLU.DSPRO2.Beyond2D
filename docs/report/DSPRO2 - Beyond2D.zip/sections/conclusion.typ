In this section, we share our perspective on the project and reflect on the results we achieved.

== Interpretation of Results
The results of our experiments show that Beyond2D can significantly improve monocular absolute depth estimation when used to refine pretrained models such as Metric DepthAnythingV2. We observed notable improvements in key metrics, especially in Absolute Relative Error (AbsRel), which decreased substantially for both ViT-S and ViT-L backbones. At the same time, the threshold accuracies (δ₁, δ₂, δ₃) also improved consistently, suggesting not only more accurate depth values but also greater reliability within practical error ranges.

Upon closer inspection, we found that the pretrained DepthAnythingV2 models already perform well in capturing object shapes and structural features but tend to overestimate depth values. This likely explains why AbsRel remains high despite relatively good δ₃ scores. It appears that while these models can recognize depth relationships across a scene, they struggle to predict them on the correct absolute scale. By applying Beyond2D, this issue is significantly reduced, resulting in more accurate and well-calibrated depth predictions.

Among the two tested backbones, the ViT-L model shows the most benefit from Beyond2D fine-tuning. This may be due to its greater representational capacity, allowing it to better leverage the refinement process. The qualitative results from the DeepFurniture dataset support this: ViT-L combined with Beyond2D produces depth maps that are closer to the ground truth in scale and preserve more fine structure, although some minor details are still not fully recovered.

That said, we also observed that the fine-tuned models tend to produce smoother and sometimes overly simplified depth maps. This smoothing effect is more noticeable with the ViT-S variant but is also present with ViT-L. This suggests a trade-off: while Beyond2D clearly improves depth accuracy overall, it may also reduce spatial detail in the predictions. It is possible that longer training or additional techniques (e.g. alternative loss functions) could help retain or recover finer geometric features in future work.

== Interpretation of Model Integration
Bringing our fine-tuned DepthAnythingV2 model into the COLMAP pipeline turned out to be a really promising step forward. By switching out COLMAP's traditional patch-match stereo method with our neural depth predictions, we were able to combine the reliability of geometric SfM with the flexibility and detail of modern AI depth estimation.

Our fine-tuned model, optimized for indoor scenes via the DeepFurniture dataset, further refined these results, offering denser reconstructions with higher point counts and slightly improved scene coverage. While this introduced more noise in some cases, our post-processing pipeline, including both automated filtering and manual refinement, helped mitigate these issues and produce cleaner outputs.

Finally, instead of trying to reconstruct whole apartments in one go, we found that capturing and processing individual rooms separately, then combining them later, was a much more manageable and scalable approach. This modular strategy made it easier to control quality and fix alignment issues, especially with COLMAP itself, while still producing highly detailed, consistent reconstructions.

Overall, integrating DepthAnythingV2 into COLMAP gave us a solid upgrade in terms of depth quality and scene completeness. There's still a lot of room for improvement in this task for making high-fidelity 3D reconstruction faster, easier and more robust.

== Future Research Directions
Looking ahead, there are several promising directions that could improve our project even further:

In our research, we came across several papers mentioning that AI models can also be integrated into the Structure from Motion pipeline, particularly in the feature extraction stage. Instead of relying solely on traditional descriptors like SIFT, a learned feature extractor could help to detect and match features on challenging surfaces like blank walls, repetitive textures or low-contrast areas. This step could improve the quality of the sparse reconstruction and even more importantly, of camera poses, making the initial steps of the pipeline more robust and accurate.

Another step that we stumbled upon during the project is that COLMAP offers a lot of flexible functions, which all have fine-tunable parameters. Exploring how they interact with our integrated AI depth model and fine-tuning them for indoor scenes could further boost point density, reduce noise and lead to an overall cleaner outcome.

== Summary
Our project "Beyond2D" successfully addressed the challenge of creating 3D models of apartments from 2D images by enhancing a traditional Structure from Motion (SfM) and Multi-View Stereo (MVS) pipeline with a custom-trained monocular depth estimation model.

Our fine-tuned model demonstrated significant quantitative improvements over their pretrained counterparts, substantially reducing the absolute relative error and increasing threshold accuracies on the DeepFurniture test set. The enhanced model was then integrated into the COLMAP reconstruction pipeline, replacing its traditional depth estimation module. This hybrid approach led to visibly denser and more complete point cloud reconstructions of real-world and synthetic scenes, particularly on textureless surfaces and fine details.

While the integration proved successful and represents a promising direction, the final models still required manual post-processing to achieve production quality. The project concludes that combining classical geometric methods with specialized deep learning models is a powerful and scalable strategy for 3D reconstruction, paving the way for more accurate and accessible virtual property tours.