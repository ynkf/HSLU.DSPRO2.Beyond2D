== General information
3D reconstruction is the process of using 2D images or sensor data to create various 3D models. Generally, 3D reconstruction helps computers to understand the shape and structure of the physical world. This technology can be applied in various fields such as cultural heritage preservation, medical imaging, robotics, CAD's, virtual and augmented reality. In cultural heritage, 3D reconstruction is used to digitally preserve artifacts and sites, which is important for studying and protecting them against potential extinction. In medical imaging it helps in visualizing anatomical structures, enhancing diagnostic accuracy and even surgical planning. Robotics applies 3D reconstruction, especially in fields like environmental mapping and navigation, whereas CAD is used for creating accurate and detailed digital models of real-world objects or environments. In virtual and augmented reality, 3D reconstruction is applied to create immersive and interactive experiences. As technology improves, 3D reconstruction is becoming faster, more accurate and more widely used in everyday applications. @cv_3d_reconstruction

== Single-view and Multi-view 3D reconstruction 
3D reconstruction methods can be classified into single-view and multi-view approaches, depending on whether they only use one or multiple images as input.

*Single-view 3D reconstruction* tries to create a 3D model from just one 2D image. This process is very challenging because many 3D shapes can look the same in 2D. Traditional methods rely on cues like shading or texture, but need strong assumptions and don’t work well in real life. Deep learning methods have improved single-view 3D reconstruction results by learning 3D shapes from single images, but still face limitations in accuracy and require a lot of training data. @single_and_multi-view_images

*Multi-view reconstruction* uses several images shot from different angles, allowing more accurate and complete 3D models. Classical methods match features across images to estimate camera positions and build 3D shapes. The problem with these methods is that they often struggle with occlusions and widely spaced views. Recent deep learning techniques combine multiple views to improve results, though some methods can be slow or lose details. @single_and_multi-view_images

== 3D reconstruction methods
There are a lot of different 3D reconstruction methods, each with its advantages and disadvantages. These methods range from traditional geometric techniques like Structure from Motion (SfM) to modern deep learning approaches such as Generative Adversarial Networks (GANs) and Neural Radiance Fields (NeRF). Exploring and understanding all these different methods provides a foundation for generating 3D models from 2D images and helps us decide which method fits our use case the best.

=== Structure from Motion (SfM) with Multi-View Stereo (MVS)
SfM is a photogrammetric technique that reconstructs 3D models utilizing overlapping photographs taken from various angles. With this approach, no expensive equipment (e.g. LiDAR camera) is needed. Often, it's enough to use consumer-grade digital cameras or phones.

The pipeline for SfM begins by identifying distinctive features across images. The algorithm then finds keypoints in images that stay the same even if the object changes in size, rotation, lighting or is partly hidden. This helps match features between different images more reliably. Once features are detected, the algorithm matches these points across multiple images to find correspondences. 

Using the matched features, SfM estimates the relative position and orientation (pose) of each camera when the images were captured. This step is crucial as it establishes the spatial relationship between the different views.

With the camera poses and matched features, SfM triangulates the 3D positions of the points seen in multiple images, resulting in a sparse point cloud that outlines the basic structure of the scene.

Techniques such as bundle adjustment are applied to refine these estimates and reduce errors. @sfm

To enhance this reconstruction, Multi-View Stereo (MVS) is used to generate a dense point cloud. MVS builds on the output of SfM by exploiting pixel-level correspondences across multiple images to estimate depth maps for each view. These depth maps are then fused into a dense 3D representation. Various MVS approaches, such as plane-sweeping, patch matching or learning-based depth estimation, are designed to improve accuracy, completeness and robustness, especially in challenging regions like textureless surfaces or occlusions. The result is a highly detailed 3D model including surface geometry and texture information suitable for visualization, measurement or further processing. @mvs

#figure(image("../graphics/SfM_MVS.png", width: 75%),
  caption: [Structure from Motion and Multi-View Stereo]
)

=== Generative Adversarial Networks (GANs)
GANs are deep learning models consisting of two parts: a generator and a discriminator. The generator creates fake data and the discriminator tries to tell the difference between real and fake data. As they train together, the generator gets better at making realistic data, while the discriminator improves at spotting the fakes. This back-and-forth helps the model create high-quality, realistic results.

For 3D reconstruction, GANs can learn to model detailed 3D shapes from training data without needing labels. They can generate 3D objects in formats like voxels, point clouds or meshes. The generator takes a compressed input (called a latent vector) and turns it into a 3D shape. The discriminator checks whether the shape looks realistic and has a proper structure.

#figure(image("../graphics/GANs_pipeline.png", width: 80%),
  caption: [NeRF Learning Schematic]
)

GANs can also explore the space of possible shapes, making it possible to smoothly change one shape into another or edit object features, like switching styles or categories. They’re useful for tasks like filling in missing shape parts, creating more training data, or recovering 3D shapes from images. Because they can learn from unlabeled data and generate consistent 3D results, GANs are a valuable tool for 3D reconstruction based on data. @gans

=== Neural Radiance Fields (NeRF)
NeRF is a method for creating realistic 3D scenes, not necessarily 3D models, using a set of 2D images. It works by learning a function that maps 3D positions and viewing directions to color and density. This function is built using a neural network, which takes five inputs (5-dimensional): the 3D coordinates (x, y, z) and the 2D viewing direction (θ, φ). The network then predicts the color and density at that point in the scene.

To create a new view, NeRF sends rays from the camera into the scene and samples points along each ray. The network predicts color and density for each point and these values are combined using a technique called volume rendering to get the final color of each pixel. Since this process is differentiable, the model can be trained by comparing the predicted images with the real ones and adjusting itself to improve accuracy.

To help the network capture fine details, NeRF uses positional encoding. It also uses hierarchical sampling, which focuses more on important areas of the scene. With these techniques, NeRF can generate high-quality new views of scenes, showing detailed shapes, reflections and transparent surfaces. @nerf

#figure(image("../graphics/NeRF.png"),
  caption: [NeRF Learning Schematic]
)

== Comparison of 3D reconstruction methods
For our project, we needed to evaluate which of the three 3D reconstruction methods would be most suitable for our use case. To support this decision, we identified and compared the advantages and disadvantages of each approach.

The SfM/MVS pipeline is flexible and scalable, working with unordered image collections taken under various conditions. It produces explicit geometry like point clouds or meshes, which are usable in standard 3D software. It also runs on standard consumer hardware without needing powerful GPUs. However, it struggles with reflective or transparent surfaces and may produce incomplete reconstructions in areas with little texture or poor image coverage. The multi-stage pipeline can also be complex, with potential failure points during processing.

GANs can directly convert one or more input images into full 3D models without separate preprocessing steps. GANs are capable of generating fine texture details and can work with relatively small training datasets. They are well-suited for creating new shapes or completing partial objects. On the downside, GANs are difficult to train and often unstable, requiring careful tuning. They also tend to be limited in resolution, with many models only supporting low-resolution outputs. Additionally, training GANs is computationally expensive and time-consuming, especially for high-quality results.

NeRF can render highly realistic novel views with detailed lighting and reflections, even from a small number of 2D input images. This makes NeRF ideal for applications focused on photorealistic view synthesis. Nevertheless, it is very computationally intensive, often requiring long training times and powerful GPUs. Rendering is also slow, as each pixel requires many calculations. Furthermore, for each scene you need to train a new NeRF model and cannot easily generalize to new ones without retraining.

We chose SfM combined with MVS for our project because it offers a good balance between flexibility, scalability and practical usability. While the other two methods offer high visual quality, they require more computational resources and are harder to implement for general-purpose reconstruction tasks. SfM/MVS provided a reliable and efficient solution for our needs.

== Enhancing SfM/MVS with AI: Our Optimization Strategy
To enhance the quality and completeness of our 3D reconstructions, we aim to improve the MVS component of our pipeline by integrating a fine-tuned monocular depth estimation model. Traditional MVS approaches often struggle with indoor environments. To address this, we plan to train and fine-tune a state-of-the-art monocular depth estimation network on a dataset of indoor scenes. By leveraging deep learning's ability to infer depth from single images, this model will serve as a strong prior, providing initial dense depth maps that can guide or supplement the MVS process. These depth predictions can be used to initialize or refine the depth hypotheses in MVS, improving both convergence and output quality, especially in textureless or low-light areas.

#figure(image("../graphics/SfM_MVS_pipeline_MDE_highlighted.png", width: 70%),
  caption: [SfM/MVS pipeline with highlighted Monocular Depth Estimation]
)